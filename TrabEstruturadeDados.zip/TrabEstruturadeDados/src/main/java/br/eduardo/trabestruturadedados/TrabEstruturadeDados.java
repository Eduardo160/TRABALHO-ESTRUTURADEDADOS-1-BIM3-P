
package br.eduardo.trabestruturadedados;

import javax.swing.JOptionPane;

public class TrabEstruturadeDados {

    public static void main(String[] args) {
        int[] array;
        int[] originalArray;

        String tamanhoInput = JOptionPane.showInputDialog("Digite o "
                + "tamanho do vetor:");
        int tamanho = Integer.parseInt(tamanhoInput);
        array = new int[tamanho];
        originalArray = new int[tamanho];

        String elementosInput = JOptionPane.showInputDialog("Digite os "
                + "elementos do vetor (separados por espaço):");
        String[] elementos = elementosInput.split(" ");
        for (int i = 0; i < tamanho; i++) {
            int num = Integer.parseInt(elementos[i]);
            array[i] = num;
            originalArray[i] = num;
        }

        String[] opcoes = {"Ordenação por Inserção", "Ordenação por Seleção", 
            "Ordenação Bolha", "Sair"};
        String metodo = (String) JOptionPane.showInputDialog(null,
                "Escolha o método de ordenação:", "Escolha",
                JOptionPane.QUESTION_MESSAGE, null,
                opcoes, opcoes[0]);

        long inicioTempo = 0;
        long fimTempo = 0;
        long duracao = 0;

        switch (metodo) {
            case "Ordenação por Inserção":
                inicioTempo = System.nanoTime();
                ordenacaoInsercao(array);
                fimTempo = System.nanoTime();
                duracao = (fimTempo - inicioTempo) / 1000000;
                break;
            case "Ordenação por Seleção":
                inicioTempo = System.nanoTime();
                ordenacaoSelecao(array);
                fimTempo = System.nanoTime();
                duracao = (fimTempo - inicioTempo) / 1000000;
                break;
            case "Ordenação Bolha":
                inicioTempo = System.nanoTime();
                ordenacaoBolha(array);
                fimTempo = System.nanoTime();
                duracao = (fimTempo - inicioTempo) / 1000000;
                break;
            case "Sair":
                System.exit(0);
                break;
            default:
                metodo = "Escolha inválida";
                JOptionPane.showMessageDialog(null,
                        "Escolha inválida");
        }

        JOptionPane.showMessageDialog(null, "Vetor Original:\n" 
                +imprimirVetor(originalArray)
                + "\nVetor Ordenado (" + metodo + "):\n" + imprimirVetor(array)
                + "\nTempo de execução (" + metodo + "): " + duracao 
                + " milissegundos");
    }

    public static void ordenacaoInsercao(int[] array) {
        for (int i = 1; i < array.length; i++) {
            int chave = array[i];
            int j = i - 1;
            while (j >= 0 && array[j] > chave) {
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = chave;
        }
    }

    public static void ordenacaoSelecao(int[] array) {
        for (int i = 0; i < array.length - 1; i++) {
            int indiceMinimo = i;
            for (int j = i + 1; j < array.length; j++) {
                if (array[j] < array[indiceMinimo]) {
                    indiceMinimo = j;
                }
            }
            int temp = array[indiceMinimo];
            array[indiceMinimo] = array[i];
            array[i] = temp;
        }
    }

    public static void ordenacaoBolha(int[] array) {
        int n = array.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
    }

    public static String imprimirVetor(int[] array) {
        StringBuilder sb = new StringBuilder();
        for (int num : array) {
            sb.append(num).append(" ");
        }
        return sb.toString();
    }
}
